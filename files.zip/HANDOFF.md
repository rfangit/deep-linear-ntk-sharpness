# Deep-Linear Hessian Widget — Refactor Handoff

This document captures the state of an in-progress refactor so it can be picked
up in a fresh conversation. Upload this file plus the source files listed under
"Files to provide" and the new chat will have everything it needs.

---

## What this project is

An in-browser tutorial (two HTML pages) that trains deep linear networks and
overlays **analytic theory** for the Hessian eigenvalue spectrum on top of the
**measured** spectrum (computed via Lanczos). The widget logic is plain ES
modules driving Chart.js.

- `index.html` — blog post with two training widgets (`tw1`, `tw2`).
- `residuals.html` — a "part 2" page with one widget (`tw`) that exposes the
  full theory-overlay controls.

---

## The goal of the refactor (DONE)

Replace the old eigenvalue-prediction code with a new architecture:

1. **Store only σ(t).** The simulation evolves the analytic singular-value
   trajectory σ from the Saxe ODE (decoupled from the trained weights — it's a
   theoretical projection, NOT measured from the model) and stores **only σ**
   per step. Nothing else theory-related is stored.

2. **Two stateless theory functions**, called at plot time on stored σ:
   - `theory_GN(sigmas, sigmaStar, n, d)` → `{ aligned, cross, single_value }`
   - `theory_Hessian_full(sigmas, sigmaStar, n, d)` →
     `{ aligned, aligned_null, cross, single_value }`
   Both are **L = 2 only** (2-layer / single hidden layer). `single_value` is
   numerically identical between the two. `aligned_null` exists only in the full
   theory. There is **no** `hidden_null` and **no** `single_value_null`.

3. **Two independent user-knob axes** at the visualization layer:
   - *Which theory*: GN and/or full Hessian (drawn separately — GN dotted, full
     dash-dot — never merged into one ranking).
   - *How to plot*: top-k overall (pooled per theory) OR top-k per class.

---

## Eigenvalue formulas (L = 2), for reference

Per nonzero mode `i` (singular value `s_i`, target `s_i0`):

- **aligned**       : GN `2 s_i` ; full `3 s_i − s_i0`
- **aligned_null**  : full only, `s_i0 − s_i` (GN value would be 0)
- **single_value**  : `s_i` (residual trivial → GN == full). Count
  `r·(n−r) + r·(d−r)`.
- **cross** (unordered pair {i,k}, i<k): 4 branches from a closed form
  `computeCrossEigenvalues(s_i, s_k, s_i0, s_k0)`:
  ```
  sigma = s_i + s_k
  delta = (s_i − s_i0) − (s_k − s_k0)
  crossTerm = 4·s_i·s_k·delta² / sigma²
  D1 = sqrt((s_i0+s_k0)²        + crossTerm)
  D2 = sqrt((2·sigma−s_i0−s_k0)² + crossTerm)
  cp = sigma + (s_i−s_k)·delta/sigma
  cm = sigma − (s_i−s_k)·delta/sigma
  branch1: full 0.5(cp+D1), gn sigma
  branch2: full 0.5(cp−D1), gn sigma
  branch3: full 0.5(cm+D2), gn 0
  branch4: full 0.5(cm−D2), gn 0
  ```
  Note: per-branch (full,gn) pairing is NOT invariant at s==s0 — they match only
  as SETS. Plotting therefore sorts within a group per timepoint, not by branch.

r = min(n, d); n = outputDim, d = inputDim.

---

## Files CHANGED (these are the deliverables, all in this folder)

| File                 | Status   | What changed |
|----------------------|----------|--------------|
| `theory.js`          | MODIFIED | Added `computeCrossEigenvalues`, `theory_GN`, `theory_Hessian_full` (new grouped, stateless, L=2). Existing σ-ODE helpers (`stepSaxeODE`, `initialSingularValues`, `predictedLoss`) untouched. Old `predictedEigenvalues` / `SaxePredictor` / `predictedResidualEigenvalues` / `SaxeResidualPredictor` LEFT IN PLACE but unused — kept for validation, prune later. |
| `simulation.js`      | MODIFIED | Stores only `sigmaHistory` (`{iteration, sigmas}` per step). Evolves σ via `stepSaxeODE` each step; seeds σ at iter 0. `predictedLoss` still computed/stored (loss overlay unchanged). Removed both predictor objects and `predictedEigenvalueHistory` / `predictedResidualEigenvalueHistory`. `getState()` now returns `sigmaHistory`, `sigmaStar`, `theoryL`, `inputDim`, `outputDim`. |
| `theory-aggregate.js`| NEW      | Pure helpers: `aggregatePooled`, `aggregatePerClass`, `groupModeCount`, `pooledModeCount`, plus `GN_GROUPS`/`FULL_GROUPS`/`GROUP_LABELS`. Turns σ-history + config into Chart.js curves. |
| `visualization.js`   | MODIFIED | `RightChart` reworked: derives the theory overlay at plot time from σ-history via the aggregators. New `update(eigenvalueHistory, eta, sigmaHistory, sigmaStar, n, d)` signature. New `predictionConfig` + live setters (`setTheories`, `setTheoryEnabled`, `setPredictionStrategy`, `setPooledK`, `setClassK`, `setShowPrediction`). Reusable dataset pool. `LossChart` untouched. |
| `train_widget.js`    | MODIFIED | `initWidget` accepts `predictionConfig`, `showTheoryControls`, `maxPredDatasets`. New `initTheoryControls()` builds the control panel (GN/full checkboxes, pooled/per-class radios, pooled-k input, four per-class rows w/ k-inputs default 3, capped at group mode count). `refreshRightChart()` helper centralizes the new update signature. Old `initResidualOptionControl` removed. Legacy option name `showResidualOption` accepted as alias for `showTheoryControls`. |
| `index.html`         | MODIFIED | No behavioral change. (Reviewed; its `initWidget('tw1'/'tw2')` calls pass no `predictionConfig`, so they get the default = GN pooled top-3 dotted = prior look.) |
| `residuals.html`     | MODIFIED | Overlay host id `tw-residualOptionContainer` → `tw-theoryControlContainer`. `initWidget('tw', …)` now passes `showTheoryControls: true` + a `predictionConfig` (GN+full, pooled, k=3). Caption updated. |

---

## Files NEEDED but UNCHANGED (provide these so imports resolve)

These are dependencies the changed files import. They were NOT modified:

- `state.js`        (AppState; provides dims, η, ε, depth flags)
- `matrix.js`       (buildMComponentsFromSpec; imports `rng.js`)
- `hessian.js`      (Lanczos — measured eigenvalues, the comparison target)
- `incremental-cache.js` (chart downsampling/EMA)
- `chart-utils.js`  (Chart.js shared options)
- `ntk-app.js`      (separate static NTK explainer widgets; independent of all
                     the above — uses its own math)
- `styles.css`

### NOT uploaded in the original session (needed to actually RUN/train)

These five are imported by `simulation.js` (and `rng.js` by `matrix.js`) but
were never provided. They were STUBBED only to run integration tests — the real
versions live in the actual project and must NOT be overwritten by any stubs:

- `model.js`         (MLP)
- `training.js`      (Trainer)
- `inputs.js`        (generateInputs)
- `data-generator.js`(generateLinearData)
- `rng.js`           (mulberry32, seededRandn)

If continuing work that touches these, ask the user to provide them.

---

## Default-behavior / backward-compat contract

- `RightChart` with **no** `predictionConfig` ⇒ `{ theories:['gn'],
  strategy:'pooled', k:kEigs, show:true }` ⇒ neutral black dotted, GN, pooled
  top-kEigs. **Verified rank-for-rank identical** to the old
  `predictedEigenvalues` top-3 across a full trajectory.
- σ trajectory + predicted loss are **bit-for-bit identical** to the old
  `SaxePredictor` (same `stepSaxeODE`, same ε^L seed, same dt=η).
- `index.html` therefore looks/behaves exactly as before.

---

## INTERFACE BREAK to remember

`RightChart.update()` signature changed:
- OLD: `update(eigenvalueHistory, eta, predictedEigenvalueHistory, predictedResidualEigenvalueHistory)`
- NEW: `update(eigenvalueHistory, eta, sigmaHistory, sigmaStar, n, d)`

And `getState()` no longer returns `predictedEigenvalueHistory` /
`predictedResidualEigenvalueHistory` — it returns `sigmaHistory` + `sigmaStar` +
`inputDim` + `outputDim` + `theoryL`. Any other caller of these must be updated.

---

## Verification done

- `theory.js`: 17 unit tests — group counts; GN/full `single_value` identical;
  cross set-symmetry; residual-vanishing set identity at s==s0; early-training
  global-max is `aligned_null`; recompute-from-stored-σ works.
- `simulation.js`: σ trajectory + loss bit-for-bit vs old predictor.
- `theory-aggregate.js`: 14 tests incl. index.html GN-top-3 parity, per-class
  "top 3 aligned + top 10 cross", over-request capping, gn≠full mid-training.
- `visualization.js`: 15 tests via mock Chart.js — index defaults, both theories
  drawn separately, per-class colors/counts, live setters, pool overflow guard.
- `train_widget.js`: full `initWidget` construction for index/residuals/legacy
  configs; theory panel renders; every control handler fires without throwing.

(Tests were ad-hoc Node `.mjs` scripts, not committed. The full module graph
runs under Node with a mock Chart.js + DOM.)

---

## Suggested NEXT STEPS

1. **Validate full-Hessian numbers against measured Lanczos spectra.** The GN
   path is proven to match prior behavior, and the full-Hessian formulas pass
   the spec's own invariants, but they have NOT been checked against the
   measured eigenvalues now that the overlay can display them. This is the
   natural next validation.
2. After (1) confirms, **prune** the now-unused `predictedEigenvalues`,
   `predictedResidualEigenvalues`, `SaxePredictor`, `SaxeResidualPredictor` from
   `theory.js`.
3. Provide the five un-uploaded modules if any further work touches training.
4. Optional: per-class color legend polish on `residuals.html`; the L≠2 notice
   is wired (theory is L=2-only).

---

## UPDATE — general-L GN + L≠2 gating + legend fix (latest session)

Two issues were fixed after the initial refactor:

### 1. Multi-layer (general-L) Gauss-Newton theory restored

`theory_GN` now takes a depth argument: `theory_GN(sigmas, sigmaStar, n, d, L = 2)`.

- **L === 2**: unchanged closed-form path via `computeCrossEigenvalues`
  (preserves the 4-branch cross structure, the zero GN branches, and the
  verified index.html top-3 parity). aligned = `2 s_i`.
- **L !== 2**: depth-general path using
  `gnCrossEig(sk, si, L) = Σ_{ℓ=1..L} s_k^(2(ℓ−1)/L)·s_i^(2(L−ℓ)/L)`.
  Diagonal (k=i) → `aligned` (= `L·s_i^(2(L−1)/L)`); each off-diagonal ORDERED
  pair → one `cross` record (no zero branches — those are 2-layer-specific);
  `single_value = s_i` per mode (depth-independent; multiplicity for L>2 is not
  modeled and does not affect GN values). Verified to match the old
  `predictedEigenvalues` on the aligned+cross set for L = 1, 3, 4.

`theory_Hessian_full` remains **strictly L = 2**.

### 2. Full Hessian is never evaluated for L ≠ 2

Depth `L` is threaded through the whole plot path:
- `theory-aggregate.js`: all four public fns + `evalTheory` take `L = 2` (last
  arg); `theory_GN` is called with it (full ignores it, always L=2).
- `visualization.js`: `update(... , L = 2)` caches `_lastL`;
  `_buildPredictionCurves` filters `'full'` out of the theories list when
  `L !== 2`, so `theory_Hessian_full` is never called off-2-layer.
- `train_widget.js`: passes `state.theoryL` as the new last arg of every
  `rightChart.update(...)`; in `initTheoryControls` the "full Hessian" checkbox
  is disabled + forced off when `L !== 2`, with a notice explaining the GN
  theory is still valid. Depth-change listeners re-run the gating.

`getState()` already exposed `theoryL` (= weight-matrix count), so no
simulation change was needed.

### 3. Phantom legend entries before first plot (FIXED)

`RightChart` pre-allocates a 64-dataset prediction pool; before the first
`update()` these (and the empty measured `λ` datasets) leaked into the legend.
Fixes in `visualization.js`:
- Measured eigenvalue datasets now constructed with `hidden: true`.
- Legend `filter` now requires: non-empty `text` AND dataset not `hidden` AND
  `data.length > 0`. So nothing shows in the legend until it carries real,
  visible, populated curves.

### Interface note (additional)

`RightChart.update()` final signature is now:
`update(eigenvalueHistory, eta, sigmaHistory, sigmaStar, n, d, L = 2)`.

---

## UPDATE — fixed vs display run parameters + run-controls panel (latest session)

Formalized the two parameter types and added a control panel for them.

### Parameter taxonomy (defining feature)
- **Fixed (pre-run)** — determines what gets COMPUTED/STORED during the run;
  changing it invalidates stored data, so it locks once a run starts (reset to
  change). Includes: model (depth/widths/seed), target (dims/σ⋆/basis), dataset
  (nTrain/seed/input mode), training (η/ε/init mode), and **Lanczos params**
  (tracked eigenvalue count, numIters, maxIters, tolRatio).
- **Display (live)** — governs only how stored data is RENDERED; freely
  adjustable mid-run. Includes: **displayed measured-eigenvalue count**, the
  entire theory overlay (which theory, strategy, pooled/per-class k, show),
  plot scaling (log x/y, clip-to-EoS, clip-sharpness), x-axis mode, EMA window,
  predicted-loss visibility. The theory overlay is display-type *by construction*
  because only σ is stored and eigenvalues are derived at plot time.

### What changed
- `visualization.js`: `RightChart` now takes `maxDisplayEigs` (= tracked count)
  and allocates that many measured-curve datasets up front. New live setter
  `setDisplayK(k)` (clamped to `[0, maxDisplayEigs]`) re-slices from cached
  measured history without a new frame. The measured-draw loop draws the first
  `kEigs` and hides the rest.
- `train_widget.js`: new `initWidget` options —
  - `trackedEigs` (fixed; default = displayed + 3),
  - `hessianNumIters` (fixed; default 30),
  - `hessianMaxIters` (fixed; default 100),
  - `showRunControls` (bool) → renders a "RUN PARAMETERS" panel into
    `#${prefix}-runControlContainer`: displayed-eigenvalues (live),
    Lanczos-eigenvalues (fixed), Lanczos-iterations (fixed).
  The two fixed inputs write to `simulation.hessianOptions` and LOCK on run
  start (`runControlsLock`), UNLOCK on reset. Displayed count stays live.
  `Simulation` already read `kEigs`/`hessianNumIters`/`hessianMaxIters` from its
  constructor options — now `train_widget` passes them through.
- `residuals.html`: added a second `overlay-panel` ("RUN PARAMETERS") hosting
  `#tw-runControlContainer`, and `showRunControls: true` in the init call.
- `index.html`: unchanged — passes none of these, so both widgets keep
  displayed 3 / tracked 6 / numIters 30 / maxIters 100.

### Defaults (all three widgets, unchanged)
displayed eigenvalues **3**, tracked **6**, numIters **30**, maxIters **100**,
tolRatio **1e-4**.

### Known limitation
Because the chart pre-allocates `maxDisplayEigs` measured datasets at
construction (= initial tracked count), lowering "tracked" pre-run works fully,
but RAISING tracked beyond the initial ceiling only takes effect after a reset
(the chart would need to reallocate). Acceptable since tracked is a pre-run
(fixed) param anyway. If you want raise-without-reset, have `initRunControls`
reconstruct `RightChart` (or pre-allocate a generous `maxDisplayEigs`).

---

## UPDATE — high-rank display fix (latest session)

**Symptom:** displaying more than ~6 measured eigenvalues did nothing — no curve
and no legend swatch for ranks 7+.

**Root cause (visualization layer, not Lanczos):** `RightChart` pre-allocated
exactly `maxDisplayEigs` measured-curve datasets, and `train_widget.js` passed
`maxDisplayEigs: trackedEigs` (default 6). So only 6 datasets ever existed;
`setDisplayK` clamped to 6 and the run-time "tracked" knob couldn't grow the
chart's allocation. Also `eigColors`/`eigLabels` only had 10 entries.

**Fix:**
- `visualization.js`: `maxDisplayEigs` now defaults to a generous **20** (hidden
  datasets cost nothing), honoring an explicit option but never below the
  initial display count. `eigColors` extended to 20 distinct colors; labels now
  generated via a subscript helper (`λ₁`…`λ₂₀`, graceful past).
- `train_widget.js`: constructs `RightChart` with `maxDisplayEigs: 20` (or
  `options.maxEigsCeiling`), instead of pinning it to `trackedEigs`. So raising
  the tracked count + displayed count in the RUN PARAMETERS panel now has
  datasets to populate, no reset/reconstruction needed.

**Separate, still-true caveat (Lanczos degeneracy):** the deep-linear Hessian
has many *repeated* eigenvalues, and single-vector Lanczos returns each DISTINCT
eigenvalue only once (multiplicities are invisible to it; pushing past the
distinct count yields ghosts from lost orthogonality). For the default config
there are only ~9 distinct positive GN eigenvalues. So even with the display fix,
the number of *meaningful* measured curves is bounded by the distinct-eigenvalue
count, not the tracked request. If true multiplicity recovery is ever needed,
the remedy is **block (band) Lanczos** in `hessian.js` (block size = max
multiplicity to resolve) — not yet implemented.

---

## UPDATE — legend phantom-entries fix (latest session)

**Symptom:** index.html legends showed many entries before plotting (which
vanished once plotting began), and after the high-rank fix they also showed
entries for the 20 pre-allocated measured datasets that aren't drawn. They
should show only the 3 displayed eigenvalues + one "theory (GN)" entry.

**Root cause:** `RightChart` relied on a Chart.js legend `filter` that
post-processes the DEFAULT `generateLabels` output. The default generator emits
one item per dataset, and the pre-allocated hidden/empty measured datasets
(now 20) and prediction-pool datasets leaked through the filter (the filter ran
inconsistently relative to dataset state / `datasetIndex`).

**Fix:** replaced the `filter` with an explicit custom `generateLabels` (same
pattern `LossChart` already uses) that walks `chart.data.datasets` and emits a
legend item only when the dataset is **not hidden, has data, and has a
non-empty label**. Since only the first curve of each prediction group carries a
label (others are `''`), this yields exactly one entry per displayed eigenvalue
and one per theory/class group. Verified: empty legend pre-plot; exactly
`λ₁,λ₂,λ₃,2/η,theory (GN)` for index.html after plotting; entries scale up/down
live with `setDisplayK`; GN+full shows two theory entries.

---

## UPDATE — legend init/reset fix (latest session)

**Symptoms:** (1) index.html widgets showed a large legend BEFORE plotting (all
pre-allocated datasets), fixed once a run starts; (2) after reset (both pages)
the legend didn't return on the next run.

**Root cause:** the custom `generateLabels` was assigned to
`this.chart.options...` AFTER `new Chart(...)`. Chart.js's constructor does an
initial render using the DEFAULT generator (one entry per dataset) → the big
phantom legend. The custom generator only took over on a later `chart.update()`.
(The reset symptom was the same construction-time issue surfacing after the
chart was torn down/redrawn.)

**Fix (`visualization.js`, RightChart constructor):** build the options object
first, assign `generateLabels` into it, THEN pass it to `new Chart(...)`. So the
very first render — at init and after any reset — uses the custom generator.
The generator still keys on `!hidden && label && data.length > 0`, which is the
correct "currently drawn" signal; verified across the full lifecycle
(init → plot → clear → re-run) that the legend is empty when nothing is drawn
and returns correctly on each (re)plot.

Note for future test authors: mock `Chart` classes MUST honor `cfg.options`
(don't replace `this.options` with a fresh object) or the installed generator
won't be visible to assertions.

---

## UPDATE — intent-based legend (shows correct entries before plotting)

**Request:** the legend should display the KNOWN entries immediately at init
(e.g. index.html → λ₁,λ₂,λ₃ + 2/η + theory (GN)), rather than being empty until
data streams in.

**Change (`visualization.js`, RightChart):** `generateLabels` now delegates to a
new `_legendItems()` method that builds entries from CONFIGURED INTENT, not from
streamed data:
  • measured λ₁..λ_{kEigs} (live display count) in their fixed colors,
  • 2/η threshold (if enabled),
  • theory entries derived from `predictionConfig`: one per active theory in
    pooled mode, one per (theory × enabled class) in perClass mode, with the
    full theory dropped when L ≠ 2 (same gate as plotting).
So the legend is correct at init, during plotting, and after reset/clear
(it now PERSISTS through clear instead of disappearing). `setDisplayK` triggers
a chart refresh even with no data yet so the legend tracks the count live.

This supersedes the earlier "empty legend pre-plot" behavior. Tests updated
accordingly (intent_legend_test.mjs is the authoritative suite; the old
empty-pre-plot assertions in lifecycle/legend/viz_gate tests were flipped).

---

## UPDATE — first-render legend fix + displayEigs init param

**Symptom:** at init the legend showed ONLY `theory (GN)` — the λ eigenvalues
and 2/η were missing.

**Root cause:** Chart.js calls `generateLabels` from INSIDE `new Chart(...)`,
before `this.chart` has been assigned. `_legendItems()` read measured/threshold
styles from `this.chart.data.datasets`, which was `undefined` at that moment, so
those entries were skipped. The theory entries survived because they're built
from `predictionConfig`, not from datasets.

**Fix (`visualization.js`):** `_legendItems()` now builds measured + threshold
entries from style info stashed on the instance at construction (`_eigColors`,
`_eigLabel`, `_thresholdStyle`) instead of reading back `this.chart`. So the
full legend (λ₁..λ_kEigs, 2/η, theory) is correct even on the very first render.
Verified with `firstrender_test.mjs` which calls `generateLabels` during
construction.

**Per-widget display count:** added an explicit `displayEigs` init option
(legacy `kEigs` still works as an alias). `index.html` now passes
`displayEigs: 3` in both `tw1` and `tw2` so each widget declares its initial
displayed-eigenvalue count; tune per widget as desired.

---

## UPDATE — exact dense-diagonalization overlay + the init-spectrum finding

### The scientific finding (init "stuck on one eigenvalue" mystery, RESOLVED)
Built the full dense Hessian (FD per-component) and diagonalized it (Jacobi) at
the residuals.html init config (inputDim5/outputDim3/hidden30/L2,
σ⋆=[1,0.5,0.25], initScale 0.0005, aligned, whitened, P=240). Ground truth:

  init spectrum = { ±1.0, ±0.5, ±0.25, 0 }, each ±value × 30, plus 60 zeros
  (strongly INDEFINITE; stable across FD steps 1e-6..1e-3, so NOT an FD artifact).

Verdicts:
- **Lanczos is CORRECT** — returns the positive top {1.0,0.5,0.25} (largest-
  magnitude, which happen to be positive), correctly degenerate. The "single
  eigenvalue at init" appearance is overlapping degenerate curves at flat values.
- **Theory is WRONG AT INIT** — the cross-mode closed form divides by
  sigma=s_i+s_k which →0 at init, blending targets into spurious ±0.79/±0.73/
  ±0.40 values that don't exist in the true spectrum (true cross modes sit at
  clean ±s_i⋆). Theory also has no negative branch (−s_i⋆) at init. AT
  CONVERGENCE theory matches the dense spectrum EXACTLY, so the formula is right
  in its intended (post-plateau) regime, wrong only at small σ. (Cross-formula
  small-σ limit is the thing to revisit in the derivation, if desired.)

### New feature: exact eigenvalues, plotted alongside Lanczos
- `dense-hessian.js` (NEW): `buildDenseHessian` (FD, symmetrized),
  `symmetricEigenvalues` (cyclic Jacobi, ascending), `denseTopEigenvalues`
  (top-k ascending, Lanczos-compatible shape).
- `simulation.js`: `exactDiag` captured per-run (fixed, pre-run); gated to small
  P via `exactDiagMaxP` (default 400) in initialize() → `exactDiagActive`.
  `computeExactEigenvalues()` runs alongside Lanczos each step; stored in
  `exactEigenvalueHistory`; exposed in getState().
- `visualization.js`: `idx.exactEigs` dataset pool (distinct style: dark dashed
  + circle markers, EXACT_COLOR/EXACT_DASH). `update(...)` takes a trailing
  `opts.exactEigenvalueHistory`; draws top-kEigs exact curves; ONE "exact
  (dense)" legend entry. `_rescaleY` now allows a negative y.min (drops
  beginAtZero) when the exact spectrum goes negative (indefinite). `setDisplayK`
  threads exact history for live re-slice.
- `train_widget.js`: `exactDiagEnabled` flag (option `exactDiag`); checkbox in
  the RUN PARAMETERS panel (fixed; locks on run start with the Lanczos params,
  unlocks on reset); threaded into captureParams; both update() call sites pass
  the exact history.
- `residuals.html`: already had showRunControls:true, so the checkbox appears
  there automatically (defaults off — it's O(P²) grad evals + O(P³) diag/step).

NOTE: `denseTopEigenvalues` returns the algebraically-largest top-k (ascending),
matching Lanczos. So the top-k exact values at init are all positive; the
negative branch is in the full spectrum but below the top-k. To SEE the
indefiniteness in the widget, raise the displayed count (and tracked) so lower/
negative eigenvalues come into the top-k window.

All suites pass (94 tests): exact_viz, exact_e2e, firstrender, intent_legend,
highrank, displayk, viz_gate, generalL, run_controls, both_panels, legend,
lifecycle.
